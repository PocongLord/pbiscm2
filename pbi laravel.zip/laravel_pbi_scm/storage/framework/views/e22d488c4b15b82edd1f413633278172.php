<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

    <style>
        .responsive-iframe-container {
          position: relative;
          overflow: hidden;
          padding-bottom: 56.25%; /* 16:9 aspect ratio (change this value based on your iframe's aspect ratio) */
        }
      
        .responsive-iframe-container iframe {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }
      </style>
      
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="responsive-iframe-container">
              <iframe title="POWER BI MKP V.1.3 - PROD - LIVE - MANDIRICOAL" src="https://app.powerbi.com/view?r=eyJrIjoiMzVlZDZhYzktODUzZC00Y2EzLWJkMWYtMmExY2U4NTYxNTU0IiwidCI6ImRhNWZlYzcyLThkNzEtNDA3YS1iNDlhLTE2MjEyZjJlYTk4NiIsImMiOjEwfQ%3D%3D&pageName=ReportSection" frameborder="0" allowFullScreen="true"></iframe>
            </div>
          </div>
        </div>
      </div>
      
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\dashboard-scm\resources\views/dashboard.blade.php ENDPATH**/ ?>